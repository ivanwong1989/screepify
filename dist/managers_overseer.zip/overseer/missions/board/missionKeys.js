function makeHarvestKey(roomName, sourceId) {
    return `harvest:${roomName}:${sourceId}`;
}

function makeBuildKey(roomName, siteId) {
    return `build:${roomName}:${siteId}`;
}

function makePickupKey(roomName, x, y, resourceType) {
    return `pickup:${roomName}:${resourceType}:${x}:${y}`;
}

function makeRepairKey(roomName, structureType, x, y) {
    return `repair:${roomName}:${structureType}:${x}:${y}`;
}

function makeLogisticsLaneKey(roomName, fromId, toId, resourceType, slot) {
    const rt = resourceType || RESOURCE_ENERGY;
    const s = Number.isFinite(slot) ? `:s${slot}` : '';
    return `logisticsLane:${roomName}:${fromId}:${toId}:${rt}${s}`;
}

function makeLogisticsJobKey(roomName, kind, targetId, sourceId, resourceType) {
    const rt = resourceType || RESOURCE_ENERGY;
    const sourcePart = sourceId ? `:${sourceId}` : '';
    return `logisticsJob:${roomName}:${kind}:${targetId}${sourcePart}:${rt}`;
}

function makeRepairTargetKey(roomName, targetId, mode) {
    const kind = mode === 'fortify' ? 'fortify' : 'repair';
    return `${kind}:${roomName}:${targetId}`;
}

function makeUpgradeKey(roomName, variant) {
    const v = variant || 'primary';
    return `upgrade:${roomName}:${v}:controller`;
}

function makeLogisticsFleetKey(roomName) {
    return `logisticsFleet:${roomName}`;
}

function makeRemoteHarvestKey(homeRoomName, remoteRoomName, sourceId) {
    return `remoteHarvest:${homeRoomName}:${remoteRoomName}:${sourceId}`;
}

function makeRemoteHaulKey(homeRoomName, remoteRoomName, sourceId) {
    return `remoteHaul:${homeRoomName}:${remoteRoomName}:${sourceId}`;
}

function makeScoutKey(roomName) {
    return `scout:${roomName}`;
}

function makeMineralKey(roomName, mineralId) {
    return `mineral:${roomName}:${mineralId}`;
}

function makeDecongestKey(roomName, variant) {
    return `decongest:${roomName}:${variant || 'parking'}`;
}

function makeContractKey(roomName, mission) {
    if (!mission) return null;
    const type = mission.type || 'unknown';
    const name = mission.name || null;
    if (name) return `contract:${roomName}:${type}:${name}`;

    if (mission.targetId) return `contract:${roomName}:${type}:target:${mission.targetId}`;
    if (mission.sourceId) return `contract:${roomName}:${type}:source:${mission.sourceId}`;
    if (mission.pos && Number.isFinite(mission.pos.x) && Number.isFinite(mission.pos.y) && mission.pos.roomName) {
        return `contract:${roomName}:${type}:pos:${mission.pos.roomName}:${mission.pos.x}:${mission.pos.y}`;
    }
    return `contract:${roomName}:${type}:anon`;
}

function makeLegacyKey(roomName, mission) {
    return makeContractKey(roomName, mission);
}

module.exports = {
    makeHarvestKey,
    makeBuildKey,
    makePickupKey,
    makeRepairKey,
    makeLogisticsLaneKey,
    makeLogisticsJobKey,
    makeRepairTargetKey,
    makeUpgradeKey,
    makeLogisticsFleetKey,
    makeRemoteHarvestKey,
    makeRemoteHaulKey,
    makeScoutKey,
    makeMineralKey,
    makeDecongestKey,
    makeContractKey,
    makeLegacyKey
};

