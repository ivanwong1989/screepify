const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');
const contractBridge = require('managers_overseer_missions_board_detectors_detectorContractBridge');
const missionUserRemoteReserve = require('managers_overseer_missions_board_types_mission.user.remote.reserve');

function run({ room, intel, context, missionBoard }) {
    if (!room || !intel || !missionBoard) return;
    if (!missionThrottle.shouldRunDetector('userRemoteReserve', room.name, Game.time)) return;
    contractBridge.runGeneratorAsContracts({
        room,
        intel,
        context,
        missionBoard,
        namespace: 'userRemoteReserve',
        generate: missionUserRemoteReserve.generate
    });
}

module.exports = {
    type: 'userRemoteReserve',
    run
};
