const heap = require('utils_heap');
const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');

const MAX_HAULER_CARRY_PARTS = 25;
const LOGISTICS_COMPONENT_THROTTLE_STORE = 'logisticsDetectorThrottle';
const SUPPLY_SCAN_INTERVAL = 11;
const LANE_SCAN_INTERVAL = 51;
const PICKUP_SCAN_INTERVAL = 23;

function getLogisticsPriority(kind, target, isEmergency) {
    if (kind === 'supply') {
        if (target && target.structureType === STRUCTURE_TOWER) return isEmergency ? 950 : 95;
        if (target && (target.structureType === STRUCTURE_SPAWN || target.structureType === STRUCTURE_EXTENSION)) {
            return isEmergency ? 900 : 80;
        }
        return 70;
    }
    if (kind === 'link_out') return 95;
    if (kind === 'mining') return 85;
    if (kind === 'drop_mining') return 47;
    if (kind === 'scavenge') return 45;
    return 40;
}

function getAvailableAmount(source, resourceType) {
    const rt = resourceType || RESOURCE_ENERGY;
    if (!source) return 0;
    if (source.store) return source.store[rt] || 0;
    if (source.resourceType === rt && Number.isFinite(source.amount)) return source.amount;
    return 0;
}

function getSlots(source, target, carryParts, resourceType) {
    const cap = Math.max(50, carryParts * 50);
    const amount = getAvailableAmount(source, resourceType);
    if (amount <= 0) return 0;
    const dist = source.pos.getRangeTo(target.pos);
    const travelTicks = dist * 2 + 10;
    const roundTrip = travelTicks * 2 + 10;
    const demandTrips = amount / cap;
    const desiredClearTicks = 100;
    let slots = Math.ceil((demandTrips * roundTrip) / desiredClearTicks);
    slots = Math.max(1, Math.min(3, slots));
    return slots;
}

function closestByRange(pos, targets) {
    if (!pos || !Array.isArray(targets) || targets.length === 0) return null;
    let best = null;
    let bestRange = Infinity;
    for (let i = 0; i < targets.length; i++) {
        const t = targets[i];
        if (!t || !t.pos) continue;
        const r = pos.getRangeTo(t.pos);
        if (r < bestRange) {
            bestRange = r;
            best = t;
        }
    }
    return best;
}

function getComponentThrottle(roomName) {
    const store = heap.getStore(LOGISTICS_COMPONENT_THROTTLE_STORE, { ttl: 500 });
    if (!store.byRoom) store.byRoom = Object.create(null);
    if (!store.byRoom[roomName]) {
        store.byRoom[roomName] = {
            supply: 0,
            lanes: 0,
            pickup: 0
        };
    }
    return store.byRoom[roomName];
}

function shouldRunComponent(roomName, component, interval, forceRun) {
    const throttle = getComponentThrottle(roomName);
    const now = Game.time;
    if (forceRun) {
        throttle[component] = now;
        return true;
    }

    const last = Number.isFinite(throttle[component]) ? throttle[component] : 0;
    if ((now - last) < Math.max(1, interval || 1)) return false;
    throttle[component] = now;
    return true;
}

function addSupplyJobs(room, intel, context, missionBoard, isEmergency) {
    const targets = []
        .concat(intel.structures[STRUCTURE_SPAWN] || [])
        .concat(intel.structures[STRUCTURE_EXTENSION] || [])
        .concat(intel.structures[STRUCTURE_TOWER] || [])
        .concat(intel.structures[STRUCTURE_LAB] || []);

    for (let i = 0; i < targets.length; i++) {
        const target = targets[i];
        if (!target || !target.store || target.store.getFreeCapacity(RESOURCE_ENERGY) <= 0) continue;
        missionBoard.createMission('logisticsJob', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            kind: 'supply',
            targetId: target.id,
            resourceType: RESOURCE_ENERGY,
            priority: getLogisticsPriority('supply', target, isEmergency)
        }, { room, intel, context });
    }
}

function addPersistentLanes(room, intel, context, missionBoard, carryParts, isEmergency) {
    const storage = room.storage;
    if (!storage || !storage.store || storage.store.getFreeCapacity(RESOURCE_ENERGY) <= 0) return;
    const efficientSources = context && context.efficientSources ? context.efficientSources : null;
    if (!efficientSources || efficientSources.size <= 0) return;

    for (let i = 0; i < intel.sources.length; i++) {
        const srcInfo = intel.sources[i];
        if (!srcInfo || !srcInfo.id || !efficientSources.has(srcInfo.id) || !srcInfo.containerId) continue;
        const source = Game.getObjectById(srcInfo.containerId);
        if (!source || !source.pos) continue;
        const slots = getSlots(source, storage, carryParts, RESOURCE_ENERGY);
        for (let slot = 0; slot < slots; slot++) {
            missionBoard.createMission('logisticsLane', {
                sponsorRoom: room.name,
                targetRoom: room.name,
                sourceId: source.id,
                targetId: storage.id,
                resourceType: RESOURCE_ENERGY,
                slot,
                laneType: 'mining',
                priority: getLogisticsPriority('mining', storage, isEmergency),
                allowPartial: false
            }, { room, intel, context });
        }
    }

    const links = intel.structures[STRUCTURE_LINK] || [];
    const spawns = intel.structures[STRUCTURE_SPAWN] || [];
    for (let i = 0; i < links.length; i++) {
        const link = links[i];
        if (!link || !link.pos || (link.store[RESOURCE_ENERGY] || 0) <= 0) continue;
        const nearStorageOrSpawn = link.pos.inRangeTo(storage.pos, 3) || spawns.some(s => s && s.pos && link.pos.inRangeTo(s.pos, 3));
        if (!nearStorageOrSpawn) continue;
        if (room.controller && link.pos.inRangeTo(room.controller.pos, 3)) continue;

        missionBoard.createMission('logisticsLane', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            sourceId: link.id,
            targetId: storage.id,
            resourceType: RESOURCE_ENERGY,
            slot: 0,
            laneType: 'link_out',
            priority: getLogisticsPriority('link_out', storage, isEmergency),
            allowPartial: true
        }, { room, intel, context });
    }
}

function addPickupJobs(room, intel, context, missionBoard, isEmergency) {
    const miningContainerIds = new Set((intel.sources || []).map(s => s.containerId).filter(id => id));
    const allContainers = intel.structures[STRUCTURE_CONTAINER] || [];
    const nonMiningContainers = allContainers.filter(c => !miningContainerIds.has(c.id));
    const sinks = [];
    if (room.storage && room.storage.store && room.storage.store.getFreeCapacity(RESOURCE_ENERGY) > 0) sinks.push(room.storage);
    for (let i = 0; i < nonMiningContainers.length; i++) {
        const c = nonMiningContainers[i];
        if (c && c.store && c.store.getFreeCapacity(RESOURCE_ENERGY) > 0) sinks.push(c);
    }
    if (sinks.length === 0) return;

    const dropped = intel.dropped || [];
    for (let i = 0; i < dropped.length; i++) {
        const source = dropped[i];
        if (!source || source.resourceType !== RESOURCE_ENERGY || source.amount <= 100) continue;
        const sink = closestByRange(source.pos, sinks);
        if (!sink) continue;
        missionBoard.createMission('logisticsJob', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            kind: 'pickup',
            sourceId: source.id,
            targetId: sink.id,
            resourceType: RESOURCE_ENERGY,
            amountThreshold: 25,
            allowPartial: true,
            priority: getLogisticsPriority('scavenge', sink, isEmergency)
        }, { room, intel, context });
    }

    const scavenges = []
        .concat(intel.ruins || [])
        .concat(intel.tombstones || []);
    for (let i = 0; i < scavenges.length; i++) {
        const source = scavenges[i];
        if (!source || !source.store || (source.store[RESOURCE_ENERGY] || 0) <= 0) continue;
        const sink = closestByRange(source.pos, sinks);
        if (!sink) continue;
        missionBoard.createMission('logisticsJob', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            kind: 'pickup',
            sourceId: source.id,
            targetId: sink.id,
            resourceType: RESOURCE_ENERGY,
            amountThreshold: 0,
            allowPartial: true,
            priority: getLogisticsPriority('scavenge', sink, isEmergency)
        }, { room, intel, context });
    }
}

function run({ room, intel, context, missionBoard }) {
    if (!room || !missionBoard || !intel) return;
    if (context && context.opState === 'EMERGENCY') return;
    const live = missionBoard.listLiveByRoom(room.name);
    const existingLanes = live.filter(m => m.type === 'logisticsLane').length;
    let existingSupplyJobs = 0;
    let existingPickupJobs = 0;
    for (let i = 0; i < live.length; i++) {
        const mission = live[i];
        if (!mission || mission.type !== 'logisticsJob') continue;
        const kind = mission.meta && mission.meta.kind;
        if (kind === 'supply') existingSupplyJobs++;
        else if (kind === 'pickup') existingPickupJobs++;
    }
    const hasLogisticsCoverage = (existingLanes + existingSupplyJobs + existingPickupJobs) > 0;
    if (hasLogisticsCoverage && !missionThrottle.shouldRunDetector('logistics', room.name, Game.time)) return;

    const efficientSources = context && context.efficientSources ? context.efficientSources : new Set();
    if (efficientSources.size <= 0) return;

    const budget = Number.isFinite(context && context.budget) ? context.budget : room.energyCapacityAvailable;
    const estimatedCarryParts = Math.max(1, Math.floor((budget || 0) / 100));
    const carryParts = Math.min(estimatedCarryParts, MAX_HAULER_CARRY_PARTS);
    const isEmergency = (context && context.opState === 'EMERGENCY');

    const forceSupplyScan = existingSupplyJobs === 0 || room.energyAvailable < room.energyCapacityAvailable;
    const forceLaneScan = existingLanes === 0;
    const potentialPickupCount = (intel.dropped ? intel.dropped.length : 0) +
        (intel.ruins ? intel.ruins.length : 0) +
        (intel.tombstones ? intel.tombstones.length : 0);
    const forcePickupScan = existingPickupJobs === 0 && potentialPickupCount > 0;

    if (shouldRunComponent(room.name, 'supply', SUPPLY_SCAN_INTERVAL, forceSupplyScan)) {
        addSupplyJobs(room, intel, context, missionBoard, isEmergency);
    }
    if (shouldRunComponent(room.name, 'lanes', LANE_SCAN_INTERVAL, forceLaneScan)) {
        addPersistentLanes(room, intel, context, missionBoard, carryParts, isEmergency);
    }
    if (potentialPickupCount > 0 && shouldRunComponent(room.name, 'pickup', PICKUP_SCAN_INTERVAL, forcePickupScan)) {
        addPickupJobs(room, intel, context, missionBoard, isEmergency);
    }
}

module.exports = {
    type: 'logistics',
    run
};
