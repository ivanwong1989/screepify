const overseerOpportunisticRepair = require('managers_overseer_intel_overseer.opportunistic.repair');
const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');

const REPAIR_MIN_RATIO = 0.9;
const CRITICAL_WALL_HITS = 5000;
const FORTIFY_TARGET_CAP = 3;

function isFortifyTarget(structure) {
    if (!structure) return false;
    return structure.structureType === STRUCTURE_WALL || structure.structureType === STRUCTURE_RAMPART;
}

function needsRepair(structure) {
    if (!structure || !structure.hitsMax) return false;
    if (isFortifyTarget(structure)) return false;
    return structure.hits < (structure.hitsMax * REPAIR_MIN_RATIO);
}

function run({ room, intel, context, missionBoard }) {
    if (!room || !missionBoard) return;
    if (context && context.opState === 'EMERGENCY') return;
    if (!missionThrottle.shouldRunDetector('repair', room.name, Game.time)) return;

    const scan = overseerOpportunisticRepair.getRoomScan(room.name);
    if (!scan) return;

    const repairIds = Array.isArray(scan.repairIds) ? scan.repairIds : [];
    for (let i = 0; i < repairIds.length; i++) {
        const id = repairIds[i];
        const target = Game.getObjectById(id);
        if (!target || !needsRepair(target)) continue;
        const isCritical = isFortifyTarget(target)
            ? target.hits < CRITICAL_WALL_HITS
            : (target.hitsMax > 0 && (target.hits / target.hitsMax) < 0.7);
        missionBoard.createMission('repair', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            targetId: target.id,
            fortify: false,
            priority: isCritical ? 85 : 65
        }, { room, intel, context });
    }

    const fortifyPolicy = room.memory && room.memory.overseer && room.memory.overseer.fortifyPolicy
        ? room.memory.overseer.fortifyPolicy
        : null;
    const targetHits = Number.isFinite(fortifyPolicy && fortifyPolicy.target) ? fortifyPolicy.target : null;
    const economyState = context && context.economyState ? context.economyState : 'STOCKPILING';
    const allowFortifySpawn = economyState === 'UPGRADING' || !!scan.critical;

    const fortifyIds = Array.isArray(scan.fortifyIds) ? scan.fortifyIds : [];
    const fortifyTargets = [];
    for (let i = 0; i < fortifyIds.length; i++) {
        const id = fortifyIds[i];
        const target = Game.getObjectById(id);
        if (!target || !isFortifyTarget(target)) continue;
        if (Number.isFinite(targetHits) && target.hits >= targetHits) continue;
        fortifyTargets.push(target);
    }
    fortifyTargets.sort((a, b) => {
        const aRatio = a.hitsMax > 0 ? (a.hits / a.hitsMax) : 1;
        const bRatio = b.hitsMax > 0 ? (b.hits / b.hitsMax) : 1;
        return aRatio - bRatio;
    });

    for (let i = 0; i < Math.min(FORTIFY_TARGET_CAP, fortifyTargets.length); i++) {
        const target = fortifyTargets[i];
        missionBoard.createMission('repair', {
            sponsorRoom: room.name,
            targetRoom: room.name,
            targetId: target.id,
            fortify: true,
            targetHits,
            spawnAllowed: allowFortifySpawn,
            priority: allowFortifySpawn ? 55 : 35
        }, { room, intel, context });
    }
}

module.exports = {
    type: 'repair',
    run
};
