const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');
const contractBridge = require('managers_overseer_missions_board_detectors_detectorContractBridge');
const missionRemoteBuild = require('managers_overseer_missions_board_types_mission.remote.build');

function run({ room, intel, context, missionBoard }) {
    if (!room || !intel || !missionBoard) return;
    if (!missionThrottle.shouldRunDetector('remoteBuild', room.name, Game.time)) return;
    contractBridge.runGeneratorAsContracts({
        room,
        intel,
        context,
        missionBoard,
        namespace: 'remoteBuild',
        generate: missionRemoteBuild.generate
    });
}

module.exports = {
    type: 'remoteBuild',
    run
};
