const remoteUtils = require('managers_overseer_utils_overseer.remote');
const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');

function countDesiredMissions(entries) {
    let total = 0;
    for (let i = 0; i < entries.length; i++) {
        const wrapped = entries[i];
        const entry = wrapped && wrapped.entry ? wrapped.entry : null;
        const enabled = !!(wrapped && wrapped.enabled);
        if (!enabled || !entry || !Array.isArray(entry.sourcesInfo)) continue;
        for (let j = 0; j < entry.sourcesInfo.length; j++) {
            if (entry.sourcesInfo[j] && entry.sourcesInfo[j].id) total++;
        }
    }
    return total;
}

function run({ room, intel, context, missionBoard }) {
    if (!room || !missionBoard) return;
    if (context && context.opState === 'EMERGENCY') return;

    const entries = remoteUtils.getRemoteEconomicContext(room, {
        opState: context && context.opState ? context.opState : null,
        maxScoutAge: 4000
    });
    const desired = countDesiredMissions(entries);
    const existing = missionBoard.listLiveByRoom(room.name).filter(m => m.type === 'remoteHarvest').length;
    if (existing >= desired && !missionThrottle.shouldRunDetector('remoteHarvest', room.name, Game.time)) return;

    for (let i = 0; i < entries.length; i++) {
        const wrapped = entries[i];
        const remoteRoom = wrapped && wrapped.name ? wrapped.name : null;
        const entry = wrapped && wrapped.entry ? wrapped.entry : null;
        const enabled = !!(wrapped && wrapped.enabled);
        if (!enabled || !remoteRoom || !entry || !Array.isArray(entry.sourcesInfo)) continue;

        for (let j = 0; j < entry.sourcesInfo.length; j++) {
            const source = entry.sourcesInfo[j];
            if (!source || !source.id) continue;
            missionBoard.createMission('remoteHarvest', {
                sponsorRoom: room.name,
                remoteRoom,
                sourceId: source.id,
                sourcePos: { x: source.x, y: source.y, roomName: remoteRoom },
                containerId: source.containerId || null,
                containerPos: source.containerPos || null,
                standPos: source.standPos || null,
                availableSpaces: source.availableSpaces || 1,
                hasContainer: !!(source.hasContainer || source.containerId),
                priority: 80
            }, { room, intel, context });
        }
    }
}

module.exports = {
    type: 'remoteHarvest',
    run
};
