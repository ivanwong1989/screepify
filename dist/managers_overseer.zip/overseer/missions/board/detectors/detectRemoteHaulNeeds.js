const remoteUtils = require('managers_overseer_utils_overseer.remote');
const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');

function hasDropoffTarget(room, intel) {
    if (!room || !intel) return false;
    const miningContainerIds = new Set((intel.sources || []).map(s => s.containerId).filter(id => !!id));
    const allContainers = intel.structures && intel.structures[STRUCTURE_CONTAINER]
        ? intel.structures[STRUCTURE_CONTAINER]
        : [];
    const nonMiningContainers = allContainers.filter(c => !miningContainerIds.has(c.id));
    return !!(room.storage || nonMiningContainers[0]);
}

function countDesiredMissions(entries) {
    let total = 0;
    for (let i = 0; i < entries.length; i++) {
        const wrapped = entries[i];
        const entry = wrapped && wrapped.entry ? wrapped.entry : null;
        const enabled = !!(wrapped && wrapped.enabled);
        if (!enabled || !entry || !Array.isArray(entry.sourcesInfo)) continue;
        for (let j = 0; j < entry.sourcesInfo.length; j++) {
            if (entry.sourcesInfo[j] && entry.sourcesInfo[j].id) total++;
        }
    }
    return total;
}

function run({ room, intel, context, missionBoard }) {
    if (!room || !intel || !missionBoard) return;
    if (context && context.opState === 'EMERGENCY') return;
    if (!hasDropoffTarget(room, intel)) return;

    const entries = remoteUtils.getRemoteEconomicContext(room, {
        opState: context && context.opState ? context.opState : null,
        maxScoutAge: 4000
    });
    const desired = countDesiredMissions(entries);
    const existing = missionBoard.listLiveByRoom(room.name).filter(m => m.type === 'remoteHaul').length;
    if (existing >= desired && !missionThrottle.shouldRunDetector('remoteHaul', room.name, Game.time)) return;

    for (let i = 0; i < entries.length; i++) {
        const wrapped = entries[i];
        const remoteRoom = wrapped && wrapped.name ? wrapped.name : null;
        const entry = wrapped && wrapped.entry ? wrapped.entry : null;
        const enabled = !!(wrapped && wrapped.enabled);
        if (!enabled || !remoteRoom || !entry || !Array.isArray(entry.sourcesInfo)) continue;

        for (let j = 0; j < entry.sourcesInfo.length; j++) {
            const source = entry.sourcesInfo[j];
            if (!source || !source.id) continue;
            missionBoard.createMission('remoteHaul', {
                sponsorRoom: room.name,
                remoteRoom,
                sourceId: source.id,
                priority: 70
            }, { room, intel, context });
        }
    }
}

module.exports = {
    type: 'remoteHaul',
    run
};
