const missionThrottle = require('managers_overseer_missions_board_utils_missionThrottle');
const contractBridge = require('managers_overseer_missions_board_detectors_detectorContractBridge');
const missionUserRemoteClaim = require('managers_overseer_missions_board_types_mission.user.remote.claim');

function run({ room, intel, context, missionBoard }) {
    if (!room || !intel || !missionBoard) return;
    if (!missionThrottle.shouldRunDetector('userRemoteClaim', room.name, Game.time)) return;
    contractBridge.runGeneratorAsContracts({
        room,
        intel,
        context,
        missionBoard,
        namespace: 'userRemoteClaim',
        generate: missionUserRemoteClaim.generate
    });
}

module.exports = {
    type: 'userRemoteClaim',
    run
};
