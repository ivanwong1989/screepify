const missionKeys = require('managers_overseer_missions_board_missionKeys');

function upsertContractMission(room, missionBoard, namespace, contract, runtimeCtx) {
    if (!room || !missionBoard || !contract) return null;
    const key = missionKeys.makeContractKey(room.name, contract);
    if (!key) return null;

    const created = missionBoard.createMission('contract', {
        sponsorRoom: room.name,
        targetRoom: room.name,
        namespace,
        contract
    }, runtimeCtx || null);

    if (!created) return null;

    missionBoard.patchMission(key, {
        sponsorRoom: room.name,
        targetRoom: (contract.pos && contract.pos.roomName) || room.name,
        targetId: contract.targetId || contract.sourceId || null,
        priority: Number.isFinite(contract.priority) ? contract.priority : 0,
        meta: Object.assign({}, created.meta || {}, {
            namespace,
            contractType: contract.type || null,
            contractName: contract.name || null
        }),
        data: {
            contract: Object.assign({}, contract)
        },
        state: 'active',
        statusReason: null,
        updatedTick: Game.time,
        lastCheckedTick: Game.time
    });

    return key;
}

function reconcileNamespace(room, missionBoard, namespace, seenIds) {
    if (!room || !missionBoard || !namespace) return;
    const live = missionBoard.listLiveByRoom(room.name);
    const seen = seenIds || new Set();
    for (let i = 0; i < live.length; i++) {
        const mission = live[i];
        if (!mission || mission.type !== 'contract') continue;
        if (!mission.meta || mission.meta.namespace !== namespace) continue;
        if (seen.has(mission.id)) continue;
        missionBoard.markCancelled(mission.id, 'not_detected');
    }
}

function runGeneratorAsContracts({ room, intel, context, missionBoard, namespace, generate }) {
    if (!room || !intel || !missionBoard || typeof generate !== 'function') return;

    const missions = [];
    generate(room, intel, context || {}, missions);

    const seen = new Set();
    for (let i = 0; i < missions.length; i++) {
        const contract = missions[i];
        const id = upsertContractMission(room, missionBoard, namespace, contract, { room, intel, context });
        if (id) seen.add(id);
    }
    reconcileNamespace(room, missionBoard, namespace, seen);
}

module.exports = {
    upsertContractMission,
    reconcileNamespace,
    runGeneratorAsContracts
};
