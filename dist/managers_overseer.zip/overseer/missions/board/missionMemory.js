const MISSION_MEMORY_VERSION = 1;

function ensureMemory() {
    if (!Memory.missions || typeof Memory.missions !== 'object') {
        Memory.missions = {};
    }
    const board = Memory.missions;
    if (board.version !== MISSION_MEMORY_VERSION) board.version = MISSION_MEMORY_VERSION;
    if (!board.byId || typeof board.byId !== 'object') board.byId = {};
    if (!board.byRoom || typeof board.byRoom !== 'object') board.byRoom = {};
    if (!board.byType || typeof board.byType !== 'object') board.byType = {};
    if (!board.cursors || typeof board.cursors !== 'object') board.cursors = {};
    return board;
}

module.exports = {
    MISSION_MEMORY_VERSION,
    ensureMemory
};

