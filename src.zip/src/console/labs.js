var managerLabs = require('managers_structures_manager.labs');

function showLabHelp() {
    const lines = [
        'lab()                                  - show this help',
        'lab("status")                           - show lab manager status',
        'lab("on") / lab("off")                  - enable or disable lab manager',
        'lab("set", { ... })                     - patch global lab settings',
        'lab("room", roomName, { ... })          - patch per-room lab settings',
        'lab("room", roomName, "on|off")         - enable/disable per-room lab manager',
        'lab("roomsReset")                        - clear all per-room lab overrides (rooms follow global config)',
        'lab("stop")                             - set mode="idle" (stop reactions)',
        'lab("idle")                             - set mode="idle" (no reactions; optional cleanupIdle can clear labs)',
        'lab("purge")                            - set mode="purge" (clear minerals from all labs back to storage/terminal)',
        'lab("roomIdle", roomName)                - set per-room mode="idle"',
        'lab("roomPurge", roomName)               - set per-room mode="purge"',

        '',
        'Forward react shortcuts:',
        'lab("react", reagentA, reagentB, opts?)             - set global mode=react + reaction',
        'lab("roomReact", roomName, reagentA, reagentB, opts?) - set per-room mode=react + reaction',

        '',
        'Reverse shortcuts:',
        'lab("reverse", product, opts?)                      - set global mode=reverse + product',
        'lab("roomReverse", roomName, product, opts?)        - set per-room mode=reverse + product',

        '',
        'Boost shortcuts:',
        'lab("boost", { XGH2O:"labId" }, opts?)          - set boost lab assignments (stocking runs alongside react/reverse)',
        'lab("roomBoost", "W1N1", { XGH2O:"labId" }, opts?) - set per-room boost lab assignments',
        'lab("boostClear")                              - clear global boost labs',
        'lab("roomBoostClear", "W1N1")                  - clear per-room boost labs',

        '',
        'Examples:',
        'lab("react", "H", "O", { inputLabs:["id1","id2"], inputTarget:2000 })',
        'lab("roomReact", "W1N1", "ZK", "UL", { inputLabs:["id1","id2"] })',
        'lab("reverse", "GH2O", { productTarget:2000, maxReactionsPerTick:3 })',
        'lab("roomReverse", "W1N1", "XGH2O", { productTarget:5000 })'
    ];
    for (const line of lines) console.log(line);
    return 'Done';
}

function normalizeRoomName(roomName) {
    return ('' + roomName).trim().toUpperCase();
}

module.exports = function registerLabConsole() {
    global.lab = function(action, ...args) {
        const cmd = action ? ('' + action).trim().toLowerCase() : 'help';
        if (!cmd || cmd === 'help' || cmd === 'h') return showLabHelp();

        if (cmd === 'status' || cmd === 's') {
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'on' || cmd === 'enable') {
            managerLabs.applyPatch({ enabled: true });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'off' || cmd === 'disable') {
            managerLabs.applyPatch({ enabled: false });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'set') {
            const patch = args[0];
            if (!patch || typeof patch !== 'object') return 'Usage: lab("set", { ... })';
            managerLabs.applyPatch(patch);
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'room') {
            const roomName = normalizeRoomName(args[0]);
            if (!roomName) return 'Usage: lab("room", "W1N1", { ... })';
            const patch = args[1];
            if (patch === 'on' || patch === 'off') {
                managerLabs.applyRoomPatch(roomName, { enabled: patch === 'on' });
            } else if (patch && typeof patch === 'object') {
                managerLabs.applyRoomPatch(roomName, patch);
            }
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomsreset' || cmd === 'resetrooms' || cmd === 'clearrooms') {
            managerLabs.applyPatch({ rooms: null });
            const msg = 'Cleared all per-room lab overrides. All rooms now follow global lab config.';
            console.log(msg);
            return msg;
        }

        if (cmd === 'stop') {
            managerLabs.applyPatch({ mode: 'idle' });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'idle') {
            managerLabs.applyPatch({ mode: 'idle' });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'purge') {
            managerLabs.applyPatch({ mode: 'purge' });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomidle') {
            const roomName = normalizeRoomName(args[0]);
            if (!roomName) return 'Usage: lab("roomIdle", "W1N1")';
            managerLabs.applyRoomPatch(roomName, { mode: 'idle' });
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'roompurge') {
            const roomName = normalizeRoomName(args[0]);
            if (!roomName) return 'Usage: lab("roomPurge", "W1N1")';
            managerLabs.applyRoomPatch(roomName, { mode: 'purge' });
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'react') {
            const reagentA = args[0];
            const reagentB = args[1];
            const opts = args[2];

            if (!reagentA || !reagentB)
                return 'Usage: lab("react", "H", "O", { inputLabs: [...], outputLabs: [...] })';

            const patch = Object.assign({
                mode: 'react',
                reaction: {
                    reagentA,
                    reagentB
                }
            }, (opts && typeof opts === 'object') ? opts : {});

            managerLabs.applyPatch(patch);
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomreact') {
            const roomName = normalizeRoomName(args[0]);
            const reagentA = args[1];
            const reagentB = args[2];
            const opts = args[3];

            if (!roomName || !reagentA || !reagentB)
                return 'Usage: lab("roomReact", "W1N1", "H", "O", { inputLabs: [...] })';

            const patch = Object.assign({
                mode: 'react',
                reaction: {
                    reagentA,
                    reagentB
                }
            }, (opts && typeof opts === 'object') ? opts : {});

            managerLabs.applyRoomPatch(roomName, patch);
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'reverse') {
            const product = args[0];
            const opts = args[1];

            if (!product) return 'Usage: lab("reverse", "GH2O", { productTarget: 2000 })';

            const patch = {
                mode: 'reverse',
                reverse: Object.assign({ product: product }, (opts && typeof opts === 'object') ? opts : {})
            };

            managerLabs.applyPatch(patch);
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomreverse') {
            const roomName = normalizeRoomName(args[0]);
            const product = args[1];
            const opts = args[2];

            if (!roomName || !product) return 'Usage: lab("roomReverse", "W1N1", "GH2O", { productTarget: 2000 })';

            const patch = {
                mode: 'reverse',
                reverse: Object.assign({ product: product }, (opts && typeof opts === 'object') ? opts : {})
            };

            managerLabs.applyRoomPatch(roomName, patch);
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'boost') {
            const boostMap = args[0];
            const opts = args[1];

            if (!boostMap || typeof boostMap !== 'object')
                return 'Usage: lab("boost", { XGH2O: "labId1" }, { boostTarget: 2000 })  // does not change mode';

            const patch = Object.assign({
                boosts: boostMap
            }, (opts && typeof opts === 'object') ? opts : {});

            managerLabs.applyPatch(patch);
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'boostclear' || cmd === 'clearboost') {
            managerLabs.applyPatch({ boosts: null });
            const msg = managerLabs.summarize();
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomboost') {
            const roomName = normalizeRoomName(args[0]);
            const boostMap = args[1];
            const opts = args[2];

            if (!roomName || !boostMap || typeof boostMap !== 'object')
                return 'Usage: lab("roomBoost", "W1N1", { XGH2O: "labId1" })  // does not change mode';

            const patch = Object.assign({
                boosts: boostMap
            }, (opts && typeof opts === 'object') ? opts : {});

            managerLabs.applyRoomPatch(roomName, patch);
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        if (cmd === 'roomboostclear' || cmd === 'clearroomboost') {
            const roomName = normalizeRoomName(args[0]);
            if (!roomName) return 'Usage: lab("roomBoostClear", "W1N1")';
            managerLabs.applyRoomPatch(roomName, { boosts: null });
            const msg = managerLabs.summarizeRoom(roomName);
            console.log(msg);
            return msg;
        }

        return showLabHelp();
    };
};
