const missionStates = require('managers_overseer_missions_board_missionStates');
const missionClasses = require('managers_overseer_missions_board_missionClassifications');
const missionKeys = require('managers_overseer_missions_board_missionKeys');

const BUILD_WORKER_TUNING = Object.freeze({
    desiredWorkBase: 1,
    desiredWorkScaleStartRcl: 5,
    desiredWorkPerRclAboveScaleStart: 1,
    desiredWorkMax: 2,
    minCountWithStorage: 1,
    maxCountWithStorage: 1,
    minCountNoStorage: 3,
    maxCountNoStorage: 3
});

function getDesiredBuildWork(rcl) {
    const level = Number.isFinite(rcl) ? rcl : 1;
    const above = Math.max(0, level - BUILD_WORKER_TUNING.desiredWorkScaleStartRcl);
    const scaled = BUILD_WORKER_TUNING.desiredWorkBase + (above * BUILD_WORKER_TUNING.desiredWorkPerRclAboveScaleStart);
    return Math.max(1, Math.min(BUILD_WORKER_TUNING.desiredWorkMax, scaled));
}

function cleanupAssigned(mission) {
    if (!mission.assigned) mission.assigned = { primary: [], support: [] };
    if (!Array.isArray(mission.assigned.primary)) mission.assigned.primary = [];
    mission.assigned.primary = mission.assigned.primary.filter(name => !!Game.creeps[name]);
}

function hasRoomStorage(room) {
    return !!(room && room.storage);
}

function getBuildCountBounds(room, fallbackHasStorage) {
    const hasStorage = room ? hasRoomStorage(room) : (fallbackHasStorage === true);
    if (hasStorage) {
        return {
            minCount: BUILD_WORKER_TUNING.minCountWithStorage,
            maxCount: BUILD_WORKER_TUNING.maxCountWithStorage
        };
    }
    return {
        minCount: BUILD_WORKER_TUNING.minCountNoStorage,
        maxCount: BUILD_WORKER_TUNING.maxCountNoStorage
    };
}

function getMiningContainerIdSet(intel) {
    const ids = new Set();
    const sources = intel && Array.isArray(intel.sources) ? intel.sources : [];
    for (let i = 0; i < sources.length; i++) {
        const id = sources[i] && sources[i].containerId ? sources[i].containerId : null;
        if (id) ids.add(id);
    }
    return ids;
}

function getNonMiningContainerIds(room, intel, roomCache) {
    if (!room) return [];
    const miningContainerIds = getMiningContainerIdSet(intel);
    const containers = (intel && intel.structures && intel.structures[STRUCTURE_CONTAINER])
        ? intel.structures[STRUCTURE_CONTAINER]
        : (roomCache && roomCache.structuresByType && roomCache.structuresByType[STRUCTURE_CONTAINER])
            ? roomCache.structuresByType[STRUCTURE_CONTAINER]
        : room.find(FIND_STRUCTURES, { filter: s => s.structureType === STRUCTURE_CONTAINER });

    const ids = [];
    for (let i = 0; i < containers.length; i++) {
        const c = containers[i];
        if (!c || !c.id || miningContainerIds.has(c.id)) continue;
        ids.push(c.id);
    }
    return ids;
}

function getRoomCache(room) {
    if (!room || typeof global.getRoomCache !== 'function') return null;
    return global.getRoomCache(room);
}

function getBuildSites(room, intel, roomCache) {
    const sites = intel && Array.isArray(intel.constructionSites)
        ? intel.constructionSites
        : (roomCache && Array.isArray(roomCache.constructionSites))
            ? roomCache.constructionSites
            : room.find(FIND_MY_CONSTRUCTION_SITES);
    if (!sites || sites.length === 0) return [];

    // roomCache/intel can include non-owned sites; build mission should only track ours.
    const mine = [];
    for (let i = 0; i < sites.length; i++) {
        const site = sites[i];
        if (site && site.my) mine.push(site);
    }
    return mine;
}

function getBuildRoomMemo(room, intel, roomCache) {
    if (!roomCache) {
        return {
            sourceIds: intel && Array.isArray(intel.allEnergySources) ? intel.allEnergySources.map(s => s.id) : [],
            nonMiningContainerIds: getNonMiningContainerIds(room, intel, null)
        };
    }

    const existing = roomCache._buildMissionMemo;
    if (existing && existing.time === Game.time) return existing;

    const allEnergySources = (intel && Array.isArray(intel.allEnergySources)) ? intel.allEnergySources : [];
    const sourceIds = [];
    for (let i = 0; i < allEnergySources.length; i++) {
        const source = allEnergySources[i];
        if (source && source.id) sourceIds.push(source.id);
    }

    const memo = {
        time: Game.time,
        sourceIds,
        nonMiningContainerIds: getNonMiningContainerIds(room, intel, roomCache)
    };
    roomCache._buildMissionMemo = memo;
    return memo;
}

module.exports = {
    makeKey(context) {
        return missionKeys.makeBuildKey(context.targetRoom || context.sponsorRoom, context.siteId);
    },

    discover({ room, intel, context }) {
        if (!room) return [];
        const policy = context && context.policy ? context.policy : null;
        const missionGates = policy && policy.missionGates ? policy.missionGates : null;
        if (missionGates && missionGates.build === false) return [];

        const roomCache = getRoomCache(room);
        const sites = getBuildSites(room, intel, roomCache);
        if (!sites || sites.length === 0) return [];

        const rcl = (room.controller && room.controller.level) || 1;
        const requiredWork = getDesiredBuildWork(rcl);
        const countBounds = getBuildCountBounds(room, null);
        const out = [];

        for (let i = 0; i < sites.length; i++) {
            const site = sites[i];
            if (!site || !site.id) continue;
            const createContext = {
                sponsorRoom: room.name,
                targetRoom: room.name,
                siteId: site.id,
                requiredWork,
                minCount: countBounds.minCount,
                maxCount: countBounds.maxCount,
                hasStorage: hasRoomStorage(room),
                priority: 60
            };
            out.push({
                key: this.makeKey(createContext),
                createContext,
                discoveredMeta: {
                    siteId: site.id
                }
            });
        }

        return out;
    },

    create(context) {
        const now = Game.time;
        const countBounds = getBuildCountBounds(null, context.hasStorage === true);
        return {
            id: this.makeKey(context),
            key: this.makeKey(context),
            type: 'build',
            class: missionClasses.FINITE,
            state: missionStates.ACTIVE,
            sponsorRoom: context.sponsorRoom,
            targetRoom: context.targetRoom || context.sponsorRoom,
            priority: Number.isFinite(context.priority) ? context.priority : 60,
            createdTick: now,
            updatedTick: now,
            lastCheckedTick: 0,
            lastProgressTick: now,
            targetId: context.siteId,
            assigned: { primary: [], support: [] },
            demand: { role: 'builder', count: 1, bodyProfile: 'worker' },
            progress: {
                stage: 'building',
                lastProgress: 0
            },
            meta: {
                missionName: `build:${context.siteId}`,
                requiredWork: Number.isFinite(context.requiredWork) ? context.requiredWork : getDesiredBuildWork(1),
                hasStorage: context.hasStorage === true,
                minCount: Number.isFinite(context.minCount) ? context.minCount : countBounds.minCount,
                maxCount: Number.isFinite(context.maxCount) ? context.maxCount : countBounds.maxCount
            },
            statusReason: null
        };
    },

    validate(mission, runtimeCtx) {
        const roomName = mission.targetRoom || mission.sponsorRoom;
        const room = runtimeCtx && runtimeCtx.room ? runtimeCtx.room : Game.rooms[roomName];
        if (!room) return true;
        const site = Game.getObjectById(mission.targetId);
        return !!site;
    },

    refresh(mission, runtimeCtx) {
        cleanupAssigned(mission);
        const roomName = mission.targetRoom || mission.sponsorRoom;
        const room = runtimeCtx && runtimeCtx.room ? runtimeCtx.room : Game.rooms[roomName];
        const intel = runtimeCtx && runtimeCtx.intel ? runtimeCtx.intel : null;
        const roomCache = getRoomCache(room);
        const roomMemo = room ? getBuildRoomMemo(room, intel, roomCache) : null;
        const site = Game.getObjectById(mission.targetId);
        const rcl = (room && room.controller && room.controller.level) || 1;
        const requiredWork = getDesiredBuildWork(rcl);
        const countBounds = getBuildCountBounds(room, mission.meta && mission.meta.hasStorage);

        mission.meta = mission.meta || {};
        mission.meta.requiredWork = requiredWork;
        mission.meta.hasStorage = hasRoomStorage(room);
        mission.meta.minCount = countBounds.minCount;
        mission.meta.maxCount = countBounds.maxCount;
        mission.meta.missionName = mission.meta.missionName || `build:${mission.targetId}`;

        mission.progress = mission.progress || {};
        if (site && Number.isFinite(site.progress)) {
            if (!Number.isFinite(mission.progress.lastProgress)) mission.progress.lastProgress = site.progress;
            if (site.progress > mission.progress.lastProgress) {
                mission.lastProgressTick = Game.time;
                mission.progress.lastProgress = site.progress;
            }
            mission.progress.total = site.progressTotal || 0;
        }

        mission.demand = {
            role: 'builder',
            count: Math.max(0, mission.meta.minCount - mission.assigned.primary.length),
            bodyProfile: 'worker'
        };

        mission.data = {
            sourceIds: roomMemo ? roomMemo.sourceIds : [],
            nonMiningContainerIds: roomMemo ? roomMemo.nonMiningContainerIds : []
        };
    },

    isComplete(mission, runtimeCtx) {
        const roomName = mission.targetRoom || mission.sponsorRoom;
        const room = runtimeCtx && runtimeCtx.room ? runtimeCtx.room : Game.rooms[roomName];
        const site = Game.getObjectById(mission.targetId);
        if (site) return false;
        // If visible and site is gone, build is complete/removed.
        if (room) return true;
        return false;
    },

    toContractMission(mission) {
        return {
            name: mission.meta && mission.meta.missionName ? mission.meta.missionName : `build:${mission.targetId}`,
            type: 'build',
            archetype: 'builder',
            targetId: mission.targetId,
            data: {
                sourceIds: mission.data && Array.isArray(mission.data.sourceIds) ? mission.data.sourceIds : [],
                nonMiningContainerIds: mission.data && Array.isArray(mission.data.nonMiningContainerIds)
                    ? mission.data.nonMiningContainerIds
                    : []
            },
            requirements: {
                archetype: 'builder',
                requiredWork: mission.meta && Number.isFinite(mission.meta.requiredWork) ? mission.meta.requiredWork : getDesiredBuildWork(1),
                minCount: mission.meta && Number.isFinite(mission.meta.minCount) ? mission.meta.minCount : BUILD_WORKER_TUNING.minCountWithStorage,
                maxCount: mission.meta && Number.isFinite(mission.meta.maxCount) ? mission.meta.maxCount : BUILD_WORKER_TUNING.maxCountWithStorage,
                spawnFromFleet: true
            },
            priority: mission.priority || 60
        };
    }
};


