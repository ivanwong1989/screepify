const managerSpawner = require('managers_spawner_manager.room.economy.spawner');

module.exports = {
    generate: function(room, intel, context, missions) {
        const { state, budget, getMissionCensus, efficientSources } = context;
        const isEmergency = state === 'EMERGENCY';
        let availableHaulerCapacity = intel.haulerCapacity;
        const spawns = intel.structures[STRUCTURE_SPAWN] || [];
        const extensions = intel.structures[STRUCTURE_EXTENSION] || [];
        const links = intel.structures[STRUCTURE_LINK] || [];
        const storage = room.storage;

        intel.sources.forEach(source => {
            const isEfficient = efficientSources.has(source.id);
            const hasCap = availableHaulerCapacity >= 300;
            const canDropMine = (source.hasContainer || hasCap) && isEfficient;
            
            if (canDropMine && !source.hasContainer) availableHaulerCapacity -= 300;

            const hasContainer = !!source.containerId;
            let mode = canDropMine ? 'static' : 'mobile';
            if (mode === 'static' && !hasContainer) mode = 'mobile';

            let containerId = hasContainer ? source.containerId : null;
            let dropoffIds = [];
            let fallback = 'none';

            if (mode === 'static') {
                const linkNearSource = links.find(link => link.pos.inRangeTo(source.pos, 2));
                if (linkNearSource) dropoffIds.push(linkNearSource.id);
                if (containerId) dropoffIds.push(containerId);
            } else {
                dropoffIds = [
                    ...spawns.map(s => s.id),
                    ...extensions.map(e => e.id)
                ];
                if (storage) dropoffIds.push(storage.id);
                fallback = 'none';
            }

            const missionName = `harvest:${source.id}`;
            const census = getMissionCensus(missionName);
            const archStats = managerSpawner.checkBody('miner', budget);
            
            const targetWork = 5;
            const workPerCreep = archStats.work || 1;
            const desiredCount = Math.min(Math.ceil(targetWork / workPerCreep), source.availableSpaces);

            let reqCount = 0;
            if (census.workParts >= targetWork) {
                // If we're already saturated on work parts, avoid locking in extra miners.
                reqCount = Math.max(1, desiredCount);
            } else {
                const deficit = Math.max(0, targetWork - census.workParts);
                const neededNew = Math.ceil(deficit / workPerCreep);
                reqCount = Math.min(census.count + neededNew, source.availableSpaces);
                if (reqCount === 0 && targetWork > 0) reqCount = 1;
            }

            debug('mission.harvest', `[Harvest] ${room.name} ${source.id} mode=${mode} ` +
                `count=${census.count} workParts=${census.workParts}/${targetWork} ` +
                `workPerCreep=${workPerCreep} desired=${desiredCount} req=${reqCount} ` +
                `spaces=${source.availableSpaces}`);

            missions.push({
                name: missionName,
                type: 'harvest',
                archetype: 'miner',
                sourceId: source.id,
                pos: source.pos,
                requirements: {
                    archetype: 'miner',
                    count: reqCount
                },
                spawnSlots: (() => {
                    const slots = [];
                    const count = Math.max(0, reqCount || 0);
                    for (let i = 0; i < count; i++) {
                        slots.push(`harvest:${room.name}:${source.id}:${i}`);
                    }
                    return slots;
                })(),
                data: {
                    sourceId: source.id,
                    mode: mode,
                    dropoffIds: dropoffIds,
                    fallback: fallback,
                    containerId: containerId
                },
                priority: isEmergency ? 1000 : 100
            });
        });
    }
};
