﻿﻿﻿﻿var managerOverseer = require('managers_overseer_manager.room.economy.overseer');
var managerTasks = require('managers_overseer_manager.room.economy.tasks');
var managerStructures = require('managers_structures_manager.structures');
var managerSpawner = require('managers_spawner_manager.room.economy.spawner');
const managerMilitaryTasks = require('managers_admiral_manager.room.military.tasks');
const managerAdmiral = require('managers_admiral_manager.room.military.admiral');
const overseerUtils = require('managers_overseer_utils_overseer.utils');

const deriveOverallState = (opsState, combatState) => {
    if (combatState === 'SIEGE') return 'SIEGE';
    if (combatState === 'DEFEND') return 'DEFENSE';
    if (combatState === 'CAUTION' || opsState === 'EMERGENCY') return 'WATCH';
    return 'SAFE';
};

module.exports = {
    /**
     * Runs all logic for a specific owned room (Colony)
     * @param {Room} room 
     * @param {StructureSpawn} spawn 
     * @param {Creep[]} allCreeps 
     */
    run: function(room, spawn, allCreeps) {
        // 1. Overseer: Analyze the room and set high-level goals/state
        managerOverseer.run(room);

        // 2. Admiral: Combat and threat analysis for the room and sets high level goals
        managerAdmiral.run(room);

        // 2.5 Unified Room State Summary (non-breaking, additive)
        room._roomState = {
            ops: room._state,
            economy: room._economyState,
            combat: room._combatState,
            overall: deriveOverallState(room._state, room._combatState)
        };

        // 3. Tasks: Generate missions, assign creeps, and request spawns if needed
        managerTasks.run(room);

        // 3.5 Military Tasks: Handle combat creep assignments and logic
        managerMilitaryTasks.run(room);

        // 4. Visualization: Draw the room state and missions (including military)
        if (Memory.debugVisual) {
            overseerUtils.visualize(room, room._missions, room._roomState);
        }

        // 3. Spawner: Generate spawn tickets
        managerSpawner.run(room, allCreeps);

        // 4. Structures: Run structure logic (Links, Terminal/Market, etc.)
        managerStructures.run(room);
    }
}
